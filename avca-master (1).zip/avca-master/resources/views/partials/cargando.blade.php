<!-- <div class="sl-preview">
	<div class="sl-preview__spinner">
		<div id="cargando" class="sl-spinner" style="border-color: rgba(239, 127, 25, 0.15) rgba(239, 127, 25, 0.15) rgba(239, 127, 25, 0.15) rgb(239, 127, 25); width: 150px; height: 150px; border-width: 10px; animation-name: rotateClockwise; animation-duration: 0.9s;">
			
		</div>
	</div>
</div> -->

<spinner :status="Active" :color="#000" :size="150" :depth="10" :clockwise="yes" :speed="0.8"></spinner>